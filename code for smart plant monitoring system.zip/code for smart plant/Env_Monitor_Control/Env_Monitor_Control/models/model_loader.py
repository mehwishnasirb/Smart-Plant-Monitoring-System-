import openai
from langchain.chat_models import ChatOpenAI
import requests
import os
from dotenv import load_dotenv

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
openai.api_key = OPENAI_API_KEY

class ModelLoader:
    def __init__(self, SENSOR_IP, ACTUATOR_IP):
        self.llm = ChatOpenAI(model_name="gpt-3.5-turbo")
        self.SENSOR_IP = SENSOR_IP
        self.ACTUATOR_IP = ACTUATOR_IP

    def prompt_get_apis(self, query):
        return f"""
        You are an AI Assistant for an IoT-based saffron environment monitoring and control system. Your job is to generate the correct API URL based on the user's request.

        Rules for Generating API URLs:
        - The user's query may be in English or Roman Urdu.
        - Identify if the query is asking for sensor data, actuator state, or controlling an actuator.
        - If the user asks for a sensor value or actuator state, return only the corresponding API URL.
        - If the user asks to change a setting (e.g., turn on/off or adjust speed), return only the respective API URL.
        - Construct the URLs dynamically based on the provided Sensor and Actuator ESP32 IPs.
        - If the user requests a sensor or actuator that does not exist, return "None".
        - Do not include any extra text—only return the URL.

        Available Sensors:
        - Soil Moisture
        - Rain Sensor
        - Water Level Sensor
        - Air Quality Sensor (MQ-135)
        - Gas Sensor (MQ-2)
        - Temperature & Humidity Sensor (DHT-11)
        - Pressure & Temperature Sensor (BMP180)

        Available Actuators:
        - Inner Water Pump
        - Outer Water Pump
        - Fan
        - Heater
        - LED
        - Buzzer

        API Endpoints:
        
        Sensor ESP32 API Routes:
        - Set Actuator ESP32 IP:  http://{self.SENSOR_IP}:80/set_actuator_ip?ip={self.ACTUATOR_IP}
        - Get All Sensor Data:  http://{self.SENSOR_IP}:80/sensor/all

        Actuator ESP32 API Routes:
        - Set Sensor ESP32 IP:  http://{self.ACTUATOR_IP}:80/set_sensor_ip?ip={self.SENSOR_IP}
        - Get All Sensor Data (via Actuator ESP):  http://{self.ACTUATOR_IP}:80/sensor/all
        - Get All Actuator States or Status:  http://{self.ACTUATOR_IP}:80/actuator/all

        Actuator Controls:
        - Fan:
          - Turn ON: http://{self.ACTUATOR_IP}:80/actuator/fan/on
          - Turn OFF: http://{self.ACTUATOR_IP}:80/actuator/fan/off
          - Set Speed: http://{self.ACTUATOR_IP}:80/actuator/fan/speed?value=<PWM_VALUE>
          - Fan status or state : http://{self.ACTUATOR_IP}:80/actuator/all

        - Inner Water Pump:
          - Turn ON: http://{self.ACTUATOR_IP}:80/actuator/inner_pump/on
          - Turn OFF: http://{self.ACTUATOR_IP}:80/actuator/inner_pump/off
          - Set Speed: http://{self.ACTUATOR_IP}:80/actuator/inner_pump/speed?value=<PWM_VALUE>
          - Inner Pump status or state : http://{self.ACTUATOR_IP}:80/actuator/all
          

        - Outer Water Pump:
          - Turn ON: http://{self.ACTUATOR_IP}:80/actuator/outer_pump/on
          - Turn OFF: http://{self.ACTUATOR_IP}:80/actuator/outer_pump/off
          - Set Speed: http://{self.ACTUATOR_IP}:80/actuator/outer_pump/speed?value=<PWM_VALUE>
          - Outer pump status or state : http://{self.ACTUATOR_IP}:80/actuator/all
          

        - Heater:
          - Turn ON: http://{self.ACTUATOR_IP}:80/actuator/heater/on
          - Turn OFF: http://{self.ACTUATOR_IP}:80/actuator/heater/off
          - Heater status or state : http://{self.ACTUATOR_IP}:80/actuator/all
          

        - LED:
          - Turn ON: http://{self.ACTUATOR_IP}:80/actuator/led/on
          - Turn OFF: http://{self.ACTUATOR_IP}:80/actuator/led/off
          - LED status or state : http://{self.ACTUATOR_IP}:80/actuator/all
          
        - Buzzer:
          - Turn ON: http://{self.ACTUATOR_IP}:80/actuator/buzzer/on
          - Turn OFF: http://{self.ACTUATOR_IP}:80/actuator/buzzer/off
          - Buzzer status or state : http://{self.ACTUATOR_IP}:80/actuator/all
          
          
          
        User Queries and Expected Responses:
        - "Temperature batao" → http://{self.SENSOR_IP}:80/sensor/all
        - "Fan chala do" → http://{self.ACTUATOR_IP}:80/actuator/fan/on
        - "Mujhe sari sensor values chahiye" → http://{self.SENSOR_IP}:80/sensor/all
        - "Light sensor ka data chahiye" → None
        
        User Query: {query}
        
        """

    def final_prompt(self, query, respected_url=None, response_env=None):
        return f"""
        You are an AI assistant helping the user interact with the IoT-Based Saffron Environment.

        Response Rules:
        - If respected_url is provided and response_env contains valid data, explain the information clearly.
        - If respected_url is provided but returns an error, inform the user about the issue.
        - If the requested sensor or actuator is not available, politely inform the user.
        - If both response_env and respected_url are None, respond based on general saffron environment knowledge only.
        - Maintain a conversational and friendly tone, responding in the language of the user's query.
        - Return only string based response dont add response or answer keyword at start of response.
        - If user chatting in english then you should use english , if it will use roman urdu you will use too
        
        
        User Queries and Expected Responses:
        
        -User Query: Fan on kar do → Fan chala diya hai! Koi aur madad chahiye?
        -User Query: Pani ka level batao → Pani ka level 60% hai. Aur kuch?
        -User Query: Mujhe light sensor ka data chahiye → Maaf kijiye, light sensor available nahi hai.

        User Query: {query}
        Response from Environment: {response_env}
        Requested URL: {respected_url}
        
        """

    def process_input(self, user_input):
        get_url_template = self.prompt_get_apis(user_input)
        url = self.llm.predict(get_url_template)
        
        print(url)
        
        if 'http' in url:
            try:
                req_response = requests.get(url)
                if req_response.status_code == 200:
                    final_prompt_template = self.final_prompt(user_input, url, req_response.text)
                else:
                    final_prompt_template = self.final_prompt(user_input, url, "Error: Unable to fetch data.")
            except requests.RequestException:
                final_prompt_template = self.final_prompt(user_input, url, "Error: Request failed.")
        else:
            final_prompt_template = self.final_prompt(user_input)
        
        return self.llm.predict(final_prompt_template)


# model_loader = ModelLoader("192.168.43.166", "192.168.43.165")
# print(model_loader.process_input("hello"))
