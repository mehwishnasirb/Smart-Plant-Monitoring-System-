import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    DEBUG = os.environ.get('FLASK_DEBUG', 'True').lower() in ['true', '1', 't']
    SECRET_KEY = os.environ.get('SECRET_KEY', 'supersecretkey')
    OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
