from flask import Flask, request, jsonify, render_template
import requests
import logging
from config import Config
from models.model_loader import ModelLoader

app = Flask(__name__)
app.config.from_object(Config)

logging.basicConfig(level=logging.INFO)

# Default IPs (can be changed via user input)
SENSOR_IP = None
ACTUATOR_IP = None
model_loader = None  # Initialized after setting IPs

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/set_ips', methods=['POST'])
def set_ips():
    global SENSOR_IP, ACTUATOR_IP, model_loader
    data = request.json

    SENSOR_IP = data.get('sensor_ip')
    ACTUATOR_IP = data.get('actuator_ip')

    if not SENSOR_IP or not ACTUATOR_IP:
        return jsonify({"error": "Both Sensor and Actuator IPs are required"}), 400

    model_loader = ModelLoader(SENSOR_IP, ACTUATOR_IP)

    # Send Actuator IP to Sensor ESP32
    try:
        response = requests.get(f"http://{SENSOR_IP}/set_actuator_ip?ip={ACTUATOR_IP}", timeout=3)
        response.raise_for_status()
    except requests.RequestException as e:
        logging.error(f"Failed to set Actuator IP on Sensor ESP32: {e}", exc_info=True)

    # Send Sensor IP to Actuator ESP32
    try:
        response = reque sts.get(f"http://{ACTUATOR_IP}/set_sensor_ip?ip={SENSOR_IP}", timeout=3)
        response.raise_for_status()
    except requests.RequestException as e:
        logging.error(f"Failed to set Sensor IP on Actuator ESP32: {e}", exc_info=True)

    return jsonify({"status": "IPs Set", "sensor_ip": SENSOR_IP, "actuator_ip": ACTUATOR_IP})

@app.route('/get_response', methods=['POST'])
def get_response_route():
    if not model_loader:
        return jsonify(response="Please set Sensor and Actuator IPs first."), 400

    try:
        user_input = request.json.get('message', '').strip()
        if not user_input:
            return jsonify(response="No input provided."), 400

        bot_response = model_loader.process_input(user_input)
        return jsonify(response=bot_response)

    except Exception as e:
        logging.error(f"Error processing input: {e}", exc_info=True)
        return jsonify(response="An error occurred while processing your input. Please try again later."), 500

if __name__ == '__main__':
    app.run(debug=app.config['DEBUG'], host="0.0.0.0", port=5000)
