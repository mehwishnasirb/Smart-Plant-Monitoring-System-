import network
import socket
import json
from machine import Pin, PWM
import urequests

# WiFi Configuration
SSID = "Mehwish iPhone"
PASSWORD = "meshiiii"
SENSOR_ESP_IP = None  # Stores the sensor ESP32 IP

# Connect to WiFi
station = network.WLAN(network.STA_IF)
station.active(True)
station.connect(SSID, PASSWORD)
while not station.isconnected():
    pass
print("Connected to Wi-Fi", station.ifconfig())

# Initialize Actuators
fan = PWM(Pin(5), freq=1000, duty=0)
inner_pump = PWM(Pin(18), freq=1000, duty=0)
outer_pump = PWM(Pin(19), freq=1000, duty=0)
heater = Pin(21, Pin.OUT)
buzzer = Pin(23, Pin.OUT)
led = Pin(2, Pin.OUT)

# API Server Setup
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("0.0.0.0", 80))
s.listen(5)

def parse_request(request, key):
    """Extracts a query parameter from the request string."""
    try:
        if f"{key}=" in request:
            return request.split(f"{key}=")[-1].split()[0]
    except Exception:
        return None

def control_actuator(actuator, state, pwm_value=None):
    """Controls actuators based on the request."""
    try:
        if pwm_value is not None:
            pwm_value = max(0, min(1023, pwm_value))  # Ensure valid range

        if actuator == "fan":
            fan.duty(pwm_value if pwm_value is not None else (1023 if state == "on" else 0))
        elif actuator == "inner_pump":
            inner_pump.duty(pwm_value if pwm_value is not None else (1023 if state == "on" else 0))
        elif actuator == "outer_pump":
            outer_pump.duty(pwm_value if pwm_value is not None else (1023 if state == "on" else 0))
        elif actuator == "heater":
            heater.value(1 if state == "on" else 0)
        elif actuator == "buzzer":
            buzzer.value(1 if state == "on" else 0)
        elif actuator == "led":
            led.value(1 if state == "on" else 0)
        
        if pwm_value:
            return f"{actuator} speed has been changed to {pwm_value}"
        else:
            return f"{actuator} has been {state}"
    except Exception as e:
        return {"error": "Actuator control failed", "details": str(e)}

def set_sensor_ip(ip):
    """Sets the sensor ESP32 IP."""
    global SENSOR_ESP_IP
    SENSOR_ESP_IP = ip
    return {"status": "Sensor IP set", "ip": SENSOR_ESP_IP}

def get_sensor_data():
    """Fetches sensor data from the Sensor ESP32."""
    if SENSOR_ESP_IP:
        try:
            response = urequests.get(f"http://{SENSOR_ESP_IP}/sensor/all")
            return response.json()
        except Exception as e:
            return {"error": "Failed to fetch sensor data", "details": str(e)}
    return {"error": "Sensor IP not set"}

def get_actuator_status():
    """Returns the status of all actuators."""
    return {
        "fan": "on" if fan.duty() > 0 else "off",
        "inner_pump": "on" if inner_pump.duty() > 0 else "off",
        "outer_pump": "on" if outer_pump.duty() > 0 else "off",
        "heater": "on" if heater.value() == 1 else "off",
        "buzzer": "on" if buzzer.value() == 1 else "off",
        "led": "on" if led.value() == 1 else "off"
    }

while True:
    try:
        conn, addr = s.accept()
        request = conn.recv(1024).decode()
        response = {}
        
        if request:
            if "/set_sensor_ip?ip=" in request:
                ip = parse_request(request, "ip")
                response = set_sensor_ip(ip)
            elif "/sensor/all" in request:
                response = get_sensor_data()
            elif "/actuator/all" in request:
                response = get_actuator_status()
            elif "/actuator/fan/on" in request:
                response = control_actuator("fan", "on")
            elif "/actuator/fan/off" in request:
                response = control_actuator("fan", "off")
            elif "/actuator/fan/speed?value=" in request:
                speed = int(parse_request(request, "value") or 0)
                response = control_actuator("fan", "on", pwm_value=speed)
            elif "/actuator/inner_pump/on" in request:
                response = control_actuator("inner_pump", "on")
            elif "/actuator/inner_pump/off" in request:
                response = control_actuator("inner_pump", "off")
            elif "/actuator/inner_pump/speed?value=" in request:
                speed = int(parse_request(request, "value") or 0)
                response = control_actuator("inner_pump", "on", pwm_value=speed)
            elif "/actuator/outer_pump/on" in request:
                response = control_actuator("outer_pump", "on")
            elif "/actuator/outer_pump/off" in request:
                response = control_actuator("outer_pump", "off")
            elif "/actuator/outer_pump/speed?value=" in request:
                speed = int(parse_request(request, "value") or 0)
                response = control_actuator("outer_pump", "on", pwm_value=speed)
            elif "/actuator/heater/on" in request:
                response = control_actuator("heater", "on")
            elif "/actuator/heater/off" in request:
                response = control_actuator("heater", "off")
            elif "/actuator/led/on" in request:
                response = control_actuator("led", "on")
            elif "/actuator/led/off" in request:
                response = control_actuator("led", "off")
            elif "/actuator/buzzer/on" in request:
                response = control_actuator("buzzer", "on")
            elif "/actuator/buzzer/off" in request:
                response = control_actuator("buzzer", "off")
        
        conn.send("HTTP/1.1 200 OK\nContent-Type: application/json\n\n" + json.dumps(response))
    except Exception as e:
        conn.send("HTTP/1.1 500 Internal Server Error\nContent-Type: application/json\n\n" + json.dumps({"error": "Server error", "details": str(e)}))
    finally:
        conn.close()
