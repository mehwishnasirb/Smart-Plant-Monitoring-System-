import network
import socket
import json
import time
from machine import Pin, ADC
import urequests

# Uncomment and configure WiFi to connect
SSID = "Mehwish iPhone"
PASSWORD = "meshiiii"

station = network.WLAN(network.STA_IF)
station.active(True)
station.connect(SSID, PASSWORD)
while not station.isconnected():
    time.sleep(1)
print("Connected to Wi-Fi", station.ifconfig())


# Initialize Sensors (no attenuation to avoid errors)
soil_moisture = ADC(Pin(25))
rain_sensor = ADC(Pin(13))
water_level = Pin(35, Pin.IN)
air_quality = ADC(Pin(33))
gas_sensor = ADC(Pin(32))
# Removed bmp180_temp ADC; implement BMP180 via I2C if needed

ACTUATOR_ESP_IP = None  # Store actuator ESP IP

# Setup socket server
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("0.0.0.0", 80))
s.listen(5)

def read_sensors():
    try:
        return {
            "soil_moisture": soil_moisture.read(),
            "rain": rain_sensor.read(),
            "water_level": water_level.value(),
            "air_quality": air_quality.read(),
            "gas": gas_sensor.read(),
            # "temperature": None  # No BMP180 reading for now
        }
    except Exception as e:
        print("Error reading sensors:", e)
        return {}

def set_actuator_ip(ip):
    global ACTUATOR_ESP_IP
    ACTUATOR_ESP_IP = ip
    return {"status": "Actuator IP set", "ip": ACTUATOR_ESP_IP}

def send_request(url):
    if not ACTUATOR_ESP_IP:
        print("Actuator IP not set; skipping request:", url)
        return
    try:
        print("Sending request to:", url)
        response = urequests.post(url)
        response.close()
    except Exception as e:
        print("Request failed:", url, "Error:", e)

def auto_control():
    data = read_sensors()
    if not data:
        return

    # Soil moisture control
    if data["soil_moisture"] < 500:
        send_request(f"http://{ACTUATOR_ESP_IP}/actuator/inner_pump/on")
    else:
        send_request(f"http://{ACTUATOR_ESP_IP}/actuator/inner_pump/off")

    # Water level control
    if data["water_level"] == 0:
        send_request(f"http://{ACTUATOR_ESP_IP}/actuator/outer_pump/on")
    else:
        send_request(f"http://{ACTUATOR_ESP_IP}/actuator/outer_pump/off")

    # Temperature sensor missing; skipping heater and LED control
    # You can implement this once you add a real temperature sensor

    # Fan control based on rain sensor and soil moisture (example logic)
    if data["rain"] > 3000 or data["soil_moisture"] < 400:
        send_request(f"http://{ACTUATOR_ESP_IP}/actuator/fan/on")
        send_request(f"http://{ACTUATOR_ESP_IP}/actuator/inner_pump/on")
    else:
        send_request(f"http://{ACTUATOR_ESP_IP}/actuator/fan/off")

def handle_request(request):
    try:
        first_line = request.split("\n")[0]
        if "/set_actuator_ip?ip=" in first_line:
            ip = first_line.split("ip=")[-1].split(" ")[0]
            return set_actuator_ip(ip)
        elif "/sensor/all" in first_line:
            return read_sensors()
        else:
            return {"error": "Invalid request"}
    except Exception as e:
        return {"error": str(e)}

while True:
    try:
        conn, addr = s.accept()
        request = conn.recv(1024).decode()
        if request:
            response = handle_request(request)
            resp_str = json.dumps(response)
            http_response = "HTTP/1.1 200 OK\nContent-Type: application/json\n\n" + resp_str
            conn.send(http_response)
        conn.close()
        auto_control()
        time.sleep(10)
    except Exception as e:
        print("Error in main loop:", e)
        time.sleep(5)

